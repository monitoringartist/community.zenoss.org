#! /bin/bash

mkdir -p target/classes

javac -sourcepath src/main/java \
      -cp lib/json_simple-1.1.jar:lib/httpclient-4.1.2.jar:lib/httpcore-4.1.2.jar \
      -d target/classes \
      src/main/java/com/zenoss/Main.java

cp src/main/resources/jsonapi.properties target/classes
