To compile the example:

    With Maven:

        1. Download and install Apache Maven 2.2.x

        2. mvn compile

    Without Maven:

        1. mkdir lib

        2. Download json_simple-1.1.jar to the lib directory

        3. Download and unzip httpcomponents-client-4.1.2-bin.tar.gz. Move
           httpclient-4.1.2.jar, httpcore-4.1.2.jar and 
           commons-logging-1.1.1.jar to the lib directory

        4. ./compile.sh

To run the example:

    1. edit target/jsonapi.properties

    2. ./run.sh
