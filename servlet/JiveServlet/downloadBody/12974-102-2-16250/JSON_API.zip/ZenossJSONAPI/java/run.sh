#! /bin/bash

# This shell script assembles the classpath and runs the example. Before
# running this script you must compile the project with "mvn compile", or by
# following the manual compilation instructions in readme.txt.

MVN_REPO=$HOME/.m2/repository

if [ -d "$MVN_REPO" ]; then
    mkdir -p lib
    cp $MVN_REPO/com/googlecode/json-simple/json-simple/1.1/json-simple-1.1.jar lib/json_simple-1.1.jar
    cp $MVN_REPO/org/apache/httpcomponents/httpclient/4.1.2/httpclient-4.1.2.jar lib
    cp $MVN_REPO/org/apache/httpcomponents/httpcore/4.1.2/httpcore-4.1.2.jar lib
    cp $MVN_REPO/commons-logging/commons-logging/1.1.1/commons-logging-1.1.1.jar lib
fi

CLASSPATH=target/classes:lib/json_simple-1.1.jar:lib/httpclient-4.1.2.jar:lib/httpcore-4.1.2.jar:lib/commons-logging-1.1.1.jar

java -cp $CLASSPATH com.zenoss.Main
