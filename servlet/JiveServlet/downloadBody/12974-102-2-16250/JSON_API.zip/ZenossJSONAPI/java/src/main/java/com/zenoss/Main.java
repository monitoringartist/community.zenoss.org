/* Zenoss-4.x JSON API Example (java)
 *
 * This main function trivially exercises the JsonApi class that connects to
 * the Zenoss-4 JSON API.
 *
 */

package com.zenoss;

import java.util.Properties;

public class Main {

    public static void main(String[] args) throws Exception {
        Properties props = PropertyLoader.loadProperties();
        JsonApi ja = new JsonApi(props);
        System.out.println("all devices: " + ja.getDevices());
        System.out.println("all events: " + ja.getEvents());
        ja.close();
    }

}
