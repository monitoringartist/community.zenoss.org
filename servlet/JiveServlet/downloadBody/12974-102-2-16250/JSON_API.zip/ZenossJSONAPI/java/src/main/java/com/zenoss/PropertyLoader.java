/* Zenoss-4.x JSON API Example (java)
 *
 * The class defined here (JsonApi) is functionally identical to the Python
 * example given in 'api_example.py'
 *
 * The JSON and HTTP interactions require json-simple and Apache's HttpClient.
 * (http://code.google.com/p/json-simple/)
 * (http://hc.apache.org/httpcomponents-client-ga/index.html)
 */

package com.zenoss;

import java.util.Properties;
import java.io.InputStream;
import java.io.IOException;

class PropertyLoader {

    public static Properties loadProperties() {
        String name = "/jsonapi.properties";
        InputStream stream = PropertyLoader.class.getResourceAsStream(name);
        Properties props = new Properties();
        try {
            props.load(stream);
        } catch (IOException e) {
            throw new RuntimeException("Could not load " + name, e);
        }
        return props;
    }

}
