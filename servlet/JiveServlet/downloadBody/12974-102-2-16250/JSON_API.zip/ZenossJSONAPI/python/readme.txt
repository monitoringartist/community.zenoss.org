Quickstart.

Use case A: Zenoss is listening on 8080 and you are OK with the scripts using 
the same username and password settings.

    1. python setup.py build --host=<zenoss host> --username=<username> --password=<password>

    2. python setup.py install

    3. ./list_devices.py

Use case B: Zenoss is listening on 8080 and you want to specify username and
password each time you run your scripts.

    1. python setup.py build --host=<zenoss host>

    2. python setup.py install

    3. examples/event_curses.py --username=<username> --password=<password>


Details.

You can specify the following options when running "python setup.py install":

    protocol - Protocol for Zenoss URLs (http or https), default is http
    host- host running Zenoss, default is localhost, but it is a good idea to specify
          the FQDN
    port- port Zenoss is listening on, default is 8080
    username- username to login to Zenoss, default is admin
    password- password for logging into Zenoss, default is zenoss

The event_curses.py script demonstrates how you can override these settings at 
the time you run the script.

The Zenoss JSON API is divided into functional components known as routers or
actions. As seen in the example scripts, to make calls to the JSON API you must
know the name of the router. You can use the interactive python interpreter or
ipython to get a list of available routers. Here is an example of navigating 
the module using ipythons tab-completion.

    $ ipython

    In [1]: from zenjsonclient import router

    In [2]: router.
    router.detailnav  router.messaging  router.network6   router.search     router.template   
    router.device     router.mib        router.process    router.service    router.triggers   
    router.events     router.network    router.report     router.settings   router.zenpack    

    In [2]: router.events?
    Type:       EventsRouter
    Base Class: <class 'zenjsonclient.EventsRouter'>
    String Form:<zenjsonclient.EventsRouter object at 0x2028f090>
    Namespace:  Interactive
    File:       /opt/centos5/jsonapi/ZenossJSONAPI/python/zenjsonclient.py
    Docstring:  <no docstring>

    In [3]: router.events.
    router.events.acknowledge             router.events.getConfig               router.events.setConfigValues
    router.events.add_event               router.events.nextEventSummaryUpdate  router.events.unacknowledge
    router.events.classify                router.events.postNote                router.events.updateEventSummaries
    router.events.clear_heartbeats        router.events.query                   router.events.url_path
    router.events.close                   router.events.queryArchive            router.events.write_log
    router.events.column_config           router.events.queryGenerator          
    router.events.detail                  router.events.reopen                  

    In [3]: router.events.close?
    Type:       instancemethod
    Base Class: <type 'instancemethod'>
    String Form:<bound method EventsRouter.close of <zenjsonclient.EventsRouter object at 0x2028f090>>
    Namespace:  Interactive
    File:       /opt/centos5/jsonapi/ZenossJSONAPI/python/zenjsonclient.py
    Definition: router.events.close(self, evids=None, excludeIds=None, params=None, uid=None, asof=None, limit=None)
    Docstring:
    Close event(s).

    @type  evids: [string]
    @param evids: (optional) List of event IDs to close (default: None)
    @type  excludeIds: [string]
    @param excludeIds: (optional) List of event IDs to exclude from
                       close (default: None)
    @type  params: dictionary
    @param params: (optional) Key-value pair of filters for this search.
                   (default: None)
    @type  uid: string
    @param uid: (optional) Context for the query (default: None)
    @type  asof: float
    @param asof: (optional) Only close if there has been no state
                 change since this time (default: None)
    @type  limit: The maximum number of events to update in this batch.
    @param limit: (optional) Maximum number of events to update (default: None).
    @rtype:   DirectResponse
    @return:  Success message


If you can't install ipython or have trouble with tab-completion, you can do this

    $ python
    >>> import zenjsonclient
    >>> from pprint import pprint
    >>> pprint([x for x in dir(zenjsonclient.router) if not x.startswith("_")])
    ['detailnav',
     'device',
     'events',
     'messaging',
     'mib',
     'network',
     'network6',
     'process',
     'report',
     'search',
     'service',
     'settings',
     'template',
     'triggers',
     'zenpack']
    >>> 

