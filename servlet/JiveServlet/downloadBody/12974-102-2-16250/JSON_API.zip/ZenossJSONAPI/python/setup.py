#!/usr/bin/env python

import os
from distutils.core import setup
from distutils.command.build import build
from distutils.command.clean import clean
from utils import gencode

class build_with_gen(build):
    """Generate the zenjsonapi module as part of the build command"""

    user_options = build.user_options + [("protocol=", None, "Protocol for Zenoss URLs (http or https)"),
                                         ("host=", None, "host running Zenoss"),
                                         ("port=", None, "port Zenoss is listening on"),
                                         ("username=", None, "username to login to Zenoss"),
                                         ("password=", None, "password for logging into Zenoss"),
                                        ]

    def initialize_options(self):
        build.initialize_options(self)
        self.protocol = "http"
        self.host = "localhost"
        self.port = "8080"
        self.username = "admin"
        self.password = "zenoss"

    def run(self):
        gencode.main(self.protocol, self.host, self.port, self.username, self.password)
        return build.run(self)

class clean_with_remove(clean):

    def run(self):

        def remove(filename):
            try:
                os.remove(filename)
            except OSError:
                pass

        remove("zenjsonclient.py")
        remove("zenjsonclient.pyc")
        return clean.run(self)

setup(name="zenjsonclient",
      version="1.0",
      py_modules=["zenjsonclient"],
      cmdclass = {"build": build_with_gen, "clean": clean_with_remove},
     )
