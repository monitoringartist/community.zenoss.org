class ZenJsonClientError(Exception):
    pass

class Response(object):
    """A response to a query of the Zenoss JSON API
    
        action: The action (aka router) that was invoked (e.g. DeviceRouter)

        method: The method that was invoked (e.g. getDevices)

        result: a dictionary containing the result of the query. The keys of
                this dictionary depend on the action and method that was 
                called. Typically result["success"] will be True for a
                successful query and False for an unsuccessful query. For
                unsuccessful queries, typically, result["msg"] will contain an
                error message.

        tid:    the transaction ID which can be used to match up the query
                with the response

        type_:   always "rpc" for remote procedure call

        uuid:   a universally unique identifier
    """

    action = None
    method = None
    result = None
    tid = None
    type_ = None
    uuid = None

    def __init__(self, action, method, result, tid, type_, uuid):
        self.action = action
        self.method = method
        self.result = result
        self.tid = tid
        self.type_ = type_
        self.uuid = uuid

    def __repr__(self):
        from pprint import pformat
        return "<zenjsonclient.Response(action={action},\n" \
               "                        method={method},\n" \
               "                        tid={tid},\n" \
               "                        type_={type_},\n" \
               "                        uuid={uuid},\n" \
               "                        result=\n{result},\n" \
               ")>".format(action=self.action,
                           method=self.method,
                           tid=self.tid,
                           type_=self.type_,
                           uuid=self.uuid,
                           result=pformat(self.result),
                          )

def create_response(dct):
    if "type" in dct:
        dct["type_"] = dct["type"]
        del dct["type"]
    resp_attrs = (a for a in dir(Response) if not a.startswith("_"))
    for attr in resp_attrs:
        if attr not in dct:
            return dct
    return Response(**dct)

class Client(object):

    def __init__(self, protocol=DEFAULT_PROTOCOL, host=DEFAULT_HOST, port=DEFAULT_PORT, username=DEFAULT_USERNAME, password=DEFAULT_PASSWORD):
        self.protocol = protocol if (protocol is not None) else DEFAULT_PROTOCOL
        self.host = host if (host is not None) else DEFAULT_HOST
        self.port = port if (port is not None) else DEFAULT_PORT
        self.username = username if (username is not None) else DEFAULT_USERNAME
        self.password = password if (password is not None) else DEFAULT_PASSWORD
        self.base_url = "{0}://{1}:{2}".format(self.protocol, self.host, self.port)
        self.opener = None

    def open(self, url, data):
        try:
            return self.opener.open(url, data)
        except urllib2.URLError as e:
            self.opener = None
            if e.args:
                embedded_error = e.args[0]
                if isinstance(embedded_error, ssl.SSLError):
                    raise ZenJsonClientError(str(embedded_error).split(":")[-1].strip())
                elif isinstance(embedded_error, (socket.gaierror, socket.error)):
                    raise ZenJsonClientError(str(embedded_error.args[1]))
                else:
                    raise ZenJsonClientError(str(embedded_error))
            else:
                raise ZenJsonClientError(str(e))
        except httplib.InvalidURL as e:
            self.opener = None
            raise ZenJsonClientError(str(e))

    def login(self):
        self.opener = urllib2.build_opener(urllib2.HTTPCookieProcessor())
        loginParams = urllib.urlencode(dict(__ac_name = self.username,
                                            __ac_password = self.password,
                                            submitted = "true",
                                            came_from = "{0}/zport/dmd/".format(self.base_url)))
        url = "{0}/zport/acl_users/cookieAuthHelper/login".format(self.base_url)
        self.open(url, loginParams)
        self.tid = 1

    def make_request(self, url_path, action, method, data=[]):
        if self.opener is None:
            self.login()
            assert self.opener is not None
        req = urllib2.Request("{0}/zport/dmd/{1}".format(self.base_url, url_path))
        req.add_header('Content-type', 'application/json; charset=utf-8')
        req_data = json.dumps([dict(action=action, method=method, data=data, type='rpc', tid=self.tid,)])
        resp = self.open(req, req_data)
        json_str = resp.read()
        try:
            json_obj = json.loads(json_str)

        except ValueError:
            self.opener = None
            raise ZenJsonClientError("Could not authenticate to Zenoss instance or wrong port.")

        self.tid += 1
        return json_obj

client = Client()

class RouterContainer(object):
    pass

router = RouterContainer()
